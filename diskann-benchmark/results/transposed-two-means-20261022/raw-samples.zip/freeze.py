import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent

def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            digest.update(part)
    return digest.hexdigest()

def command(*args):
    return subprocess.check_output(args, cwd=root).decode('utf-8', errors='replace').strip()

if (evidence / 'provenance.json').exists():
    raise RuntimeError('Frozen provenance exists; it must not be overwritten')

datasets = {}
for name in ['yfcc','enron','fbv8_mimir']:
    spec = json.loads((evidence / f'{name}-template.json').read_text())
    data = spec['jobs'][0]['content']['dataset']
    dataset = {}
    for key in ['data','queries','groundtruth']:
        requested = Path(data[key])
        paths = [requested] if requested.is_absolute() else [Path(folder) / requested for folder in spec['search_directories']]
        path = next(p for p in paths if p.is_file())
        with path.open('rb') as stream:
            rows, cols = struct.unpack('<II', stream.read(8))
        size = path.stat().st_size
        if key == 'groundtruth':
            if size not in [8 + 4 * rows * cols, 8 + 8 * rows * cols]:
                raise ValueError(f'Unexpected groundtruth format: {path}')
        else:
            width = 2 if data.get('data_type','float32') == 'float16' else 4
            if size != 8 + rows * cols * width:
                raise ValueError(f'Unexpected input size/type: {path}')
        dataset[key] = dict(file=path.name, path=str(path), rows=rows, columns=cols, bytes=size, sha256=sha256(path))
    if dataset['data']['columns'] != dataset['queries']['columns'] or dataset['queries']['rows'] != dataset['groundtruth']['rows']:
        raise ValueError(f'Inconsistent dataset shapes: {name}')
    datasets[name] = dataset

paths = []
for folder in ['diskann/src/ivf', 'diskann-benchmark/src/graph_ivf', 'diskann-quantization/src/algorithms/kmeans',
               'diskann-vector/src/distance', 'diskann-wide/src', 'diskann-quantization/src/multi_vector']:
    paths.extend((root / folder).rglob('*.rs'))
for name in ['Cargo.lock','Cargo.toml','rust-toolchain.toml','.cargo/config.toml',
             'diskann/Cargo.toml','diskann-quantization/Cargo.toml','diskann-benchmark/Cargo.toml',
             'diskann-benchmark/src/inputs/graph_ivf.rs','diskann-benchmark/src/inputs/graph_ivf_two_means.rs',
             'diskann-benchmark/scripts/run_ivf_experiment.py','diskann-benchmark/scripts/run_ivf_abba.py',
             'diskann-benchmark/scripts/analyze_ivf_abba.py']:
    paths.append(root / name)
snapshot = evidence / 'source'
for path in paths:
    destination = snapshot / path.relative_to(root)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)

executable = evidence / 'diskann-benchmark.exe'
if executable.exists():
    if sha256(executable) != sha256(root / 'target/release/diskann-benchmark.exe'):
        raise RuntimeError('Existing frozen executable differs; do not overwrite')
else:
    shutil.copy2(root / 'target/release/diskann-benchmark.exe', executable)
diff = subprocess.check_output(['git','diff','--binary','HEAD'], cwd=root)
(evidence / 'source.patch').write_bytes(diff)
record = dict(
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_parent=command('git','rev-parse','HEAD'),
    source_note='Working-tree implementation captured file by file; parent commit plus source.patch and source/ snapshot.',
    branch=command('git','branch','--show-current'),
    base=command('git','rev-parse','u/xiajiang/graph-ivf-static-benchmark'),
    executable_sha256=sha256(executable), source_patch_sha256=sha256(evidence / 'source.patch'),
    rustc=command('rustc','-Vv'), cargo=command('cargo','-V'),
    build_command='cargo build -p diskann-benchmark --release --features ivf-two-means',
    rustflags_environment=os.environ.get('RUSTFLAGS'), cargo_target_config=(root / '.cargo/config.toml').read_text(),
    hardware=(evidence / 'hardware.txt').read_text(encoding='utf-8-sig'),
    power_plan=command('powercfg','/getactivescheme'),
    frequency_control='OS-managed; no fixed clock or exclusive-host guarantee',
    affinity=16, priority='Normal', threads=1, block_width=16, unroll=1,
    numerical_contract='Both transposed candidates are opt-in; finite rounding/cancellation may change assignments; nonfinite per-point fallback to paired L2.',
    datasets=datasets,
    sources={p.relative_to(root).as_posix(): sha256(p) for p in sorted(set(paths))},
    inputs={p.name:sha256(p) for p in sorted(evidence.glob('*input.json'))} | {p.name:sha256(p) for p in sorted(evidence.glob('*template.json'))},
    old_run='Paused; frozen executable and all prior results preserved; no timing reuse.',
)
(evidence / 'provenance.json').write_text(json.dumps(record,indent=2)+chr(10),encoding='utf-8')
print(json.dumps(dict(executable_sha256=record['executable_sha256'], source_files=len(record['sources']),
                     datasets={n:(v['data']['rows'],v['data']['columns'],v['queries']['rows']) for n,v in datasets.items()}),indent=2))
