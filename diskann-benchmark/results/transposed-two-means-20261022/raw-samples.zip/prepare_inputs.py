import copy
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
old = root / 'target/ivf-abba-20261022'

def save(path, value):
    if path.exists():
        raise RuntimeError(f'Input already exists: {path}')
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

strategies = ['paired_point', 'transposed_l2_16', 'transposed_dot_16', 'transposed_lloyd_reference']
core = dict(bucket_sizes=[128, 1024, 4096], dimensions=[128, 384, 896], iterations=[5],
            layouts=['contiguous', 'scattered'], strategies=strategies, seed=7,
            repetitions=7, warmup_repetitions=1, order='rotating')

save(evidence / 'e1-core-input.json', dict(search_directories=[], jobs=[dict(type='graph-ivf-two-means', content=core)]))

jobs = []
for seed in [42, 2026]:
    config = dict(core, seed=seed, repetitions=1, warmup_repetitions=0)
    jobs.append(dict(type='graph-ivf-two-means', content=config))
save(evidence / 'e1-seed-check-input.json', dict(search_directories=[], jobs=jobs))

shapes = set()
shapes.update((n,384,5,'contiguous') for n in [32,128,512,1024,2048,4096,16384])
shapes.update((1024,d,5,'contiguous') for d in [64,128,192,384,896,1536])
shapes.update((1024,d,i,layout) for d in [128,384,896] for i in [1,5,10] for layout in ['contiguous','scattered'])
jobs = []
for n,d,i,layout in sorted(shapes):
    for candidate in strategies[1:3]:
        config = dict(bucket_sizes=[n], dimensions=[d], iterations=[i], layouts=[layout], seed=7,
                      repetitions=4, warmup_repetitions=1, order='abba', strategies=['paired_point', candidate])
        jobs.append(dict(type='graph-ivf-two-means', content=config))
save(evidence / 'e1-boundaries-input.json', dict(search_directories=[], jobs=jobs))

for dataset in ['yfcc','enron','fbv8_mimir']:
    template = json.loads((old / f'{dataset}-template.json').read_text())
    save(evidence / f'{dataset}-template.json', template)
    index = copy.deepcopy(template['jobs'][0]['content'])
    index.pop('search', None)
    index['dataset'].pop('queries', None)
    index['dataset'].pop('groundtruth', None)
    replay = dict(index=index, directory=(evidence / f'{dataset}-parents').as_posix(),
                  parent_ordinals=[0,128,512], seed=7, repetitions=7, warmup_repetitions=1)
    save(evidence / f'{dataset}-replay-input.json', dict(search_directories=template['search_directories'],
              jobs=[dict(type='graph-ivf-parent-replay', content=replay)]))

save(evidence / 'input-scope.json', dict(core_shapes=18, boundary_shapes=len(shapes),
     boundary_blocks_per_candidate=4, replay_parent_ordinals=[0,128,512],
     build_search_blocks_per_dataset_candidate=1, build_search_invocations=24,
     default_unchanged=True, candidate_numerical_differences_allowed_and_reported=True))
print('Prepared core, boundary, seed, replay and three full-query ABBA templates.')
