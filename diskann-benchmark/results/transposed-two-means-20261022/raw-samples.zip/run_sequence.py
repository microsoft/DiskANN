import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
scripts = root / 'diskann-benchmark/scripts'
sys.path.insert(0, str(scripts))
from run_ivf_experiment import sha256

frozen = json.loads((evidence / 'provenance.json').read_text())
exe = evidence / 'diskann-benchmark.exe'
if sha256(exe) != frozen['executable_sha256']:
    raise RuntimeError('Frozen executable changed')

for name in ['e1-core','e1-seed-check','e1-boundaries','yfcc-replay','enron-replay','fbv8_mimir-replay']:
    source = evidence / f'{name}-input.json'
    output = evidence / f'{name}.json'
    metadata = output.with_suffix('.metadata.json')
    if sha256(source) != frozen['inputs'][source.name]:
        raise RuntimeError(f'Frozen input changed: {source}')
    if metadata.exists():
        meta = json.loads(metadata.read_text())
        if meta['exit_code'] != 0 or meta['executable_sha256'] != frozen['executable_sha256'] or meta['input_sha256'] != sha256(source):
            raise RuntimeError(f'Existing result needs inspection: {output}')
    else:
        print(f'Starting {name}', flush=True)
        subprocess.run([sys.executable, str(scripts / 'run_ivf_experiment.py'), '--exe', str(exe),
                        '--input', str(source), '--output', str(output), '--affinity', '16'], check=True, cwd=root)
    results = json.loads(output.read_text())
    if 'replay' not in name:
        for job in results:
            for workload in job['results']['workloads']:
                for strategy in workload['strategies']:
                    if strategy['strategy'] != 'transposed_lloyd_reference' and strategy['status'] != 'complete':
                        raise RuntimeError(f'Candidate failed: {name}')

command = [sys.executable, str(scripts / 'run_ivf_abba.py'), '--exe', str(exe),
           '--output-directory', str(evidence / 'runs'), '--rounds', '1', '--affinity', '16',
           '--reference', 'paired_point', '--candidate', 'transposed_l2_16', '--candidate', 'transposed_dot_16']
for name in ['yfcc','enron','fbv8_mimir']:
    command.extend(['--dataset', f'{name}={evidence / (name + "-template.json")}'])
print('Starting 24 full build+search ABBA invocations', flush=True)
subprocess.run(command, check=True, cwd=root)
subprocess.run([sys.executable, str(scripts / 'analyze_ivf_abba.py'), str(evidence / 'runs'),
                '--output', str(evidence / 'summary.json')], check=True, cwd=root)
print('All new measurements complete.', flush=True)
