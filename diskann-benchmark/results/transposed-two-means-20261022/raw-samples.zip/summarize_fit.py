import json
from pathlib import Path
import statistics

evidence = Path(__file__).resolve().parent

def load(name):
    return json.loads((evidence / name).read_text())

def collect(jobs, stage):
    records = []
    for job in jobs:
        for workload in job['results']['workloads']:
            strategies = workload['strategies']
            baseline = next(s for s in strategies if s['strategy'] == 'paired_point')
            for row in strategies:
                samples = row['total_samples_ns']
                assert len(samples) == row['samples']
                if samples:
                    assert abs(statistics.mean(samples) - row['total_ns']['mean']) < 1e-6
                record = dict(stage=stage, seed=job['input']['content']['seed'], **workload['workload'],
                              **row, ratio_to_paired=(row['total_ns']['mean']/baseline['total_ns']['mean']) if samples else None,
                              preparation_fraction=(row['preparation_ns']['mean']/row['total_ns']['mean']) if samples else None)
                if job['input']['content'].get('order') == 'abba':
                    a = baseline['total_samples_ns']
                    b = samples
                    assert len(a) == len(b) and len(a) % 2 == 0
                    record['paired_block_means_ns'] = [[statistics.mean(a[i:i+2]),statistics.mean(b[i:i+2])] for i in range(0,len(a),2)]
                    record['paired_block_reductions_pct'] = [100*(1-y/x) for x,y in record['paired_block_means_ns']]
                records.append(record)
    return records

records = collect(load('e1-core.json'), 'core')
records += collect(load('e1-boundaries.json'), 'boundary_abba')
records += collect(load('e1-seed-check.json'), 'seed_diagnostic')
for dataset in ['yfcc','enron','fbv8_mimir']:
    result = load(dataset + '-replay.json')[0]['results']
    for parent in result['parents']:
        snapshot = parent['snapshot']
        jobs = [dict(input=dict(content=dict(seed=7)), results=dict(workloads=parent['workloads']))]
        for row in collect(jobs,'parent_replay'):
            row.update(dataset=dataset, parent_ordinal=snapshot['ordinal'], inserted_so_far=snapshot['inserted_so_far'])
            records.append(row)

output = dict(records=records, noncomplete=[r for r in records if r['status'] != 'complete'],
              divergences=[r for r in records if r['diagnostics'] and r['diagnostics']['first_divergent_iteration'] is not None])
(evidence / 'fit-summary.json').write_text(json.dumps(output,indent=2)+chr(10),encoding='utf-8')
print('records',len(records),'failures',len(output['noncomplete']),'divergent_cases',len(output['divergences']))
